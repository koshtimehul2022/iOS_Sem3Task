//
//  TableCell.swift
//  PersistDataWithTableView
//
//  Created by Hiren Masaliya on 03/10/24.
//

import UIKit

class TableCell: UITableViewCell {

    @IBOutlet weak var lblPunchLine: UILabel!
    @IBOutlet weak var lblSetup: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
