//
//  ViewController.swift
//  PersistDataWithTableView
//
//  Created by Hiren Masaliya on 03/10/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnClick(_ sender: Any) {
        let def = UserDefaults.standard
        def.setValue(txtName.text!, forKey: "Name")
        performSegue(withIdentifier: "SecoundVC", sender: self)
    }
    
}

