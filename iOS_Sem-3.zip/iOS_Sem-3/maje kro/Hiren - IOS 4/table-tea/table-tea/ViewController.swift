//
//  ViewController.swift
//  table-tea
//
//  Created by Hiren Masaliya on 05/09/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTable()
    }
}

extension ViewController: UITableViewDelegate,UITableViewDataSource{
    
    func setupTable(){
        table.delegate = self
        table.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! TableViewCell
        
        cell.lblText.text = "This is Table Cell"
        
        return cell
    }
    
}
