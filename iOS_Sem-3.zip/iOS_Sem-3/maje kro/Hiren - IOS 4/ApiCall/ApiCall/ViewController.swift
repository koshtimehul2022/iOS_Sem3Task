//
//  ViewController.swift
//  ApiCall
//
//  Created by Hiren Masaliya on 26/09/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var LodingIndicater: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    
    var jokes : [JokeModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.LodingIndicater.startAnimating()
        ApiManage().callApi { res in
            switch res {
            case .success(let data):
                self.jokes.append(contentsOf: data)
                self.tableView.reloadData()
                self.LodingIndicater.stopAnimating()
                self.LodingIndicater.isHidden = true
            case .failure(let error):
                debugPrint(error)
            }
        }
    }
        
        
}
    
extension ViewController : UITableViewDelegate,UITableViewDataSource{
        
        func setupTableView(){
            tableView.dataSource = self
            tableView.delegate = self
            tableView.register(UINib(nibName: "TVCell", bundle: nil), forCellReuseIdentifier: "TVCell")
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return jokes.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TVCell", for: indexPath) as! TVCell
            
            cell.lblSetUp.text = jokes[indexPath.row].setup
            cell.lblPunchline.text = jokes[indexPath.row].punchline
            
            return cell
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 80
        }
        
        
}
