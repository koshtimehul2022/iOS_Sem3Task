//
//  ApiManage.swift
//  ApiCall
//
//  Created by Hiren Masaliya on 26/09/24.
//

import Foundation
import Alamofire

class ApiManage {
    
    func callApi(completionHandeler:@escaping(Result<[JokeModel],Error>)->Void){
        let urlstr = callType()
        
        AF.request(urlstr).responseDecodable(of: [JokeModel].self) { respones in
            switch respones.result {
                
            case .success(let data):
                completionHandeler(.success(data))
            case .failure(let error):
                completionHandeler(.failure(error))
            }
        }
    }
    
    func callType() -> String{
        
        let types = "programming"
        
        let url = "https://official-joke-api.appspot.com/jokes/"+(types)+"/ten"
        
        return url
    }
}
