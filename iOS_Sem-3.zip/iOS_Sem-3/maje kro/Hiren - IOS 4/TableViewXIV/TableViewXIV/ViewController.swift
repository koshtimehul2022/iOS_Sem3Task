//
//  ViewController.swift
//  TableViewXIV
//
//  Created by Hiren Masaliya on 10/09/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var jokeTable: UITableView!
    
    var jokes : [JokeModel] = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchJokes()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
    }
    
    func fetchJokes(){
        let urlstr = "https://official-joke-api.appspot.com/jokes/random/25"
        
        if let url = URL(string: urlstr) {
            
            let session = URLSession.shared
            
            let dataTask = session.dataTask(with: url){data,respones,error in
                
                guard let jokeData = data else { return }
                
                do {
                    let jokes = try JSONDecoder().decode([JokeModel].self, from: jokeData)
                    self.jokes.append(contentsOf: jokes)
                    
                    DispatchQueue.main.async {
                        self.jokeTable.reloadData()
                    }
                    
                    print(self.jokes)
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }
            dataTask.resume()
        }
    }


}

struct JokeModel: Codable {
    let id: Int
    let type: String
    let setup: String
    let punchline: String
}

extension ViewController : UITableViewDelegate,UITableViewDataSource {
    
    
    
    func setupTableView(){
        jokeTable.delegate = self
        jokeTable.dataSource = self
        jokeTable.register(UINib(nibName: "TableVcCell", bundle: nil), forCellReuseIdentifier: "TableVcCell")
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return jokes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableVcCell", for: indexPath) as! TableVcCell
        
        cell.lblName.text = jokes[indexPath.row].setup
        cell.lblSubTitle.text = jokes[indexPath.row].punchline
        
        return cell
    }

}

