//
//  ViewController.swift
//  NewApiTestDemo
//
//  Created by Hiren Masaliya on 08/10/24.
//

import UIKit

class ViewController: UIViewController {
    
    var catsList : [CatsModel] = []
    
    var currentCat : CatsModel!

    @IBOutlet weak var tableVIew: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if catsList.isEmpty {
            ApiService().callApi { res in
                switch res {
                case .success(let data):
                    self.catsList.append(contentsOf: data)
                    self.tableVIew.reloadData()
                case .failure(let error):
                    print(error)
                }
            }
        }
        
    }


}

extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func setupTableView() {
        tableVIew.dataSource = self
        tableVIew.delegate = self
        tableVIew.register(UINib(nibName: "CatsCell", bundle: nil), forCellReuseIdentifier: "CatsCell")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return catsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableVIew.dequeueReusableCell(withIdentifier: "CatsCell", for: indexPath) as! CatsCell
        
        cell.lblId.text = String(catsList[indexPath.row].id)
        cell.lblName.text = catsList[indexPath.row].name
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentCat = catsList[indexPath.row]
        performSegue(withIdentifier: "DetailsVC", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "DetailsVC"{
            if let data = segue.destination as? DetailsVC{
                data.thiscat = currentCat
            }
        }
    }
    
    
}


