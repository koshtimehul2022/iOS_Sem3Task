//
//  ApiService.swift
//  NewApiTest
//
//  Created by Hiren Masaliya on 08/10/24.
//

import Foundation
import Alamofire

class ApiService {
    
    func callApi(cv : @escaping(Result<[NewApiModel],Error>)->Void) {
        let urlstr = "https://freetestapi.com/api/v1/cats?limit=5"
        
        AF.request(urlstr).responseDecodable(of: [NewApiModel].self) { res in
            switch res.result {
            case .success(let data):
                cv(.success(data))
            case .failure(let error):
                cv(.failure(error))
            }
        }
        
    }
}
