//
//  NewApiModel.swift
//  NewApiTest
//
//  Created by Hiren Masaliya on 08/10/24.
//

import Foundation

struct NewApiModel : Codable{
    let id : Int
    let name : String
    let origin : String
    let temperament : String
    //let colors : [String]
    let description : String
    let image : String
}
