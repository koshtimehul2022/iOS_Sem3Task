//
//  TVCell.swift
//  ApiTest
//
//  Created by Hiren Masaliya on 05/10/24.
//

import UIKit

class TVCell: UITableViewCell {

    @IBOutlet weak var lblSetup: UILabel!
    @IBOutlet weak var lblPunchline: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
