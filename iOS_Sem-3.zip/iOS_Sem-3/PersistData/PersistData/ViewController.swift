//
//  ViewController.swift
//  PersistData
//
//  Created by Hiren Masaliya on 03/10/24.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
//        let defaults = UserDefaults.standard
//        
//        defaults.setValue("John", forKey: "UserName") // set user data
//        var user = defaults.string(forKey: "UserName") // get user data
//        print(user!)
//        
//        defaults.setValue("John1", forKey: "UserName")
//        var user1 = defaults.string(forKey: "UserName")
//        print(user1!)
        
        
    }
    
    
    @IBAction func btnClick(_ sender: Any) {
        let UserName = txtName.text
        let defaults = UserDefaults.standard
        defaults.setValue(UserName, forKey: "User")
        performSegue(withIdentifier: "SecoundVC", sender: self)
    }
    

}

