//
//  SecoundVC.swift
//  PersistData
//
//  Created by Hiren Masaliya on 03/10/24.
//

import UIKit

class SecoundVC: UIViewController {

    @IBOutlet weak var lblUser: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setUserName()
    }
    
    func setUserName() {
        let defaults = UserDefaults.standard
        let name = defaults.string(forKey: "User")
        navigationItem.title = "Hello, \(name!)"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
