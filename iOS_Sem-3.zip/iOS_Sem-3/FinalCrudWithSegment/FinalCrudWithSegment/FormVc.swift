//
//  FormVc.swift
//  FinalCrudWithSegment
//
//  Created by Mobile5 on 12/12/24.
//

import UIKit
import CoreData

class FormVc: UIViewController {
    
    
    @IBOutlet weak var idTxt: UITextField!
    @IBOutlet weak var typeTxt: UITextField!
    @IBOutlet weak var setuptxt: UITextField!
    @IBOutlet weak var punchlineTxt: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func saveDatatoCd(_ sender: Any) {
        
        var id = Int(idTxt.text!)!
        var type = typeTxt.text!
        var setup = setuptxt.text!
        var punchline = punchlineTxt.text!
        
        
        addToCoreData(dataObject: JokeModal(id: id, type: type, setup: setup, punchline: punchline))
       
    }
    
    func addToCoreData(dataObject:JokeModal){
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else{return}
        
        let managedContext = delegate.persistentContainer.viewContext
        
        guard let jokeEntity = NSEntityDescription.entity(forEntityName: "Jokes", in: managedContext) else{return}
        
        let joke = NSManagedObject(entity: jokeEntity, insertInto: managedContext)
        
        joke.setValue(dataObject.id, forKey: "id")
        joke.setValue(dataObject.type, forKey: "type")
        joke.setValue(dataObject.setup , forKey: "setup")
        joke.setValue(dataObject.punchline, forKey: "punchline")
        
        
        do{
            try managedContext.save()
            
            debugPrint("Data Saved.!")
            
            let alert = UIAlertController(title: "Success", message: "data Added Successfully..!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        catch let err as NSError{
            debugPrint("Error Occured :\(err)")
        }
    }
    
    
}
