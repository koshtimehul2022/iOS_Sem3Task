//
//  JokeModel.swift
//  ApiCallWIthTableView
//
//  Created by Hiren Masaliya on 02/10/24.
//

import Foundation


class JokeModel : Codable {
    let id : Int
    let type : String
    let setup : String
    let punchline : String
}
