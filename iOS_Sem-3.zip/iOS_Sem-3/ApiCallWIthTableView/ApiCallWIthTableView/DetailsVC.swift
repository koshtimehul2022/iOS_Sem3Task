//
//  DetailsVC.swift
//  ApiCallWIthTableView
//
//  Created by Hiren Masaliya on 02/10/24.
//

import UIKit

class DetailsVC: UIViewController {
    
    @IBOutlet weak var lblPunchline: UILabel!
    @IBOutlet weak var lblSetup: UILabel!
    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblType: UILabel!
    
    var selectedJoke : JokeModel!

    override func viewDidLoad() {
        super.viewDidLoad()

        setText()
    }
    
    func setText(){
        lblId.text = String(selectedJoke.id)
        lblType.text = selectedJoke.type
        lblSetup.text = selectedJoke.setup
        lblPunchline.text = selectedJoke.punchline
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
