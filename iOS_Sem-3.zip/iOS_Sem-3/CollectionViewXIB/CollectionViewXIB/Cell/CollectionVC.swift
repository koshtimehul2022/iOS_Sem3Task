//
//  CollectionVC.swift
//  CollectionViewXIB
//
//  Created by Hiren Masaliya on 19/09/24.
//

import UIKit

class CollectionVC: UICollectionViewCell {

    @IBOutlet weak var punchlineLabel: UILabel!
    @IBOutlet weak var setUpLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
