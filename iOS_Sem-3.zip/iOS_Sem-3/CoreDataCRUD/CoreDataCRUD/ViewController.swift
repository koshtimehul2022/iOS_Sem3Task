//
//  ViewController.swift
//  PracticeCRUD
//
//  Created by sanskruti chaudhari on 25/12/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var jokeID: UITextField!
    @IBOutlet weak var jokeType: UITextField!
    
    @IBOutlet weak var jokesetup: UITextField!
    
    @IBOutlet weak var jokePunchline: UITextField!
    
    var txtJokeId: String!
    var txtJokeType: String!
    var txtJokeSetup: String!
    var txtJokePunchline: String!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    

    @IBAction func btnSubmit(_ sender: Any) {
        txtJokeId = jokeID.text
        txtJokeType = jokeType.text
        txtJokeSetup = jokesetup.text
        txtJokePunchline = jokePunchline.text
        InsertData(jokeObj: jokeModal(id: txtJokeId,
                                      type: txtJokeType,
                                      setup: txtJokeSetup,
                                      punchline: txtJokePunchline))
    }
    
    
    func InsertData (jokeObj : jokeModal) {
        
        guard let delegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let context = delegate.persistentContainer.viewContext
        
        guard let entity = NSEntityDescription.entity(forEntityName: "Jokes", in: context) else { return }
        
        let newJoke = NSManagedObject(entity: entity, insertInto: context)
        
        newJoke.setValue(jokeObj.id, forKey: "id")
        newJoke.setValue(jokeObj.type, forKey: "type")
        newJoke.setValue(jokeObj.setup, forKey: "setup")
        newJoke.setValue(jokeObj.punchline, forKey: "punchline")
        
        do{
            try context.save()
            debugPrint("SuccessFully...")
        }catch let error as NSError {
            debugPrint("Failed to insert data: \(error), \(error.userInfo)")
        }
        
    }
    
    
    @IBAction func readDataBtn(_ sender: Any) {
        
    }
    
}

