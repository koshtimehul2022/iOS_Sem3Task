//
//  UpdateDataVC.swift
//  PracticeCRUD
//
//  Created by sanskruti chaudhari on 25/12/24.
//

import UIKit
import CoreData

class UpdateDataVC: UIViewController {
    
    
    @IBOutlet weak var updateID: UITextField!
    
    @IBOutlet weak var updateType: UITextField!
    
    @IBOutlet weak var updatePunchline: UITextField!
    @IBOutlet weak var updateSetup: UITextField!
    
    var readdata : jokeModal!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateID.text = readdata.id
        updateType.text = readdata.type
        updatePunchline.text = readdata.punchline
        updateSetup.text = readdata.setup
        
    }
    

    @IBAction func upadteBtn(_ sender: Any) {
        
        updateCoreData(atId: readdata.id, updateData: jokeModal(
            id: updateID.text!,
            type: updateType.text!,
            setup: updateSetup.text!,
            punchline: updatePunchline.text!))
    }
    
    
    func updateCoreData(atId : String,updateData : jokeModal){
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            let fetchdata = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
            
            fetchdata.predicate = NSPredicate(format: "id = %@", atId)
            
            do{
                
                let delete = try context.fetch(fetchdata)
                let obj = delete[0] as! NSManagedObject

                
                obj.setValue(updateData.id, forKey: "id")
                obj.setValue(updateData.type, forKey: "type")
                obj.setValue(updateData.setup, forKey: "setup")
                obj.setValue(updateData.punchline, forKey: "punchline")
                
                try context.save()
                print("Updated successfully")
                
            }catch{
                debugPrint("Updated Failed..")
            }
        }

}
