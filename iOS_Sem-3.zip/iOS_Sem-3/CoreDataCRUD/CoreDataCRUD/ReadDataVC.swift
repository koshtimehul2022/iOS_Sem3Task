//
//  ReadDataVC.swift
//  PracticeCRUD
//
//  Created by sanskruti chaudhari on 25/12/24.
//

import UIKit
import CoreData

class ReadDataVC: UIViewController {

    var dataArr : [jokeModal] = []
    var getID : jokeModal!
    
    @IBOutlet weak var dataTblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
    }

}

extension ReadDataVC : UITableViewDataSource , UITableViewDelegate {
    
    func setUp(){
        dataTblView.dataSource = self
        dataTblView.delegate = self
        dataTblView.register(UINib(nibName: "jokeCell", bundle: nil), forCellReuseIdentifier: "jokeCell")
        dataArr = ReadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let cell = dataTblView.dequeueReusableCell(withIdentifier: "jokeCell") as! jokeCell
        cell.idLbl.text = dataArr[indexPath.row].id
        cell.typeLbl.text = dataArr[indexPath.row].type
        cell.setupLbl.text = dataArr[indexPath.row].setup
        cell.punchlineLbl.text = dataArr[indexPath.row].punchline
        return cell
    }
    
    
    func ReadData() -> [jokeModal]{
        
        var readArr : [jokeModal] = []
        let delegate = UIApplication.shared.delegate as? AppDelegate
        
        let context = delegate!.persistentContainer.viewContext
        
        let fetchReq = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        do{
            let res = try context.fetch(fetchReq)
            
            for data in res as! [NSManagedObject]{
                readArr.append(jokeModal(id: data.value(forKey: "id") as! String,
                                         type: data.value(forKey: "type") as! String,
                                         setup: data.value(forKey: "setup") as! String,
                                         punchline: data.value(forKey: "punchline") as! String))
                dataTblView.reloadData()
                debugPrint("fetch Done")
            }
            
        }catch{
            debugPrint("Error in fetching")
        }
        return readArr
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = UIContextualAction(style: .normal, title: "Delete") { _, _, complete in
            
            
            let ObjectData = self.dataArr[indexPath.row]
         
            self.DeleteData(jokeObj: ObjectData)
            
            self.dataArr.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with:.automatic)
            DispatchQueue.main.async {
                self.dataTblView.reloadData()
                 }
            complete(true)
                
        }
        delete.backgroundColor = .red
        return UISwipeActionsConfiguration(actions: [delete])
    }
    
    
    func DeleteData(jokeObj : jokeModal){
        
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let context = delegate.persistentContainer.viewContext
        
        let fetchReq = NSFetchRequest<NSFetchRequestResult>(entityName: "Jokes")
        
        let predicate = NSPredicate(format: "id == %@", jokeObj.id)
        
        do {
            let result = try context.fetch(fetchReq)
            
            guard let del = result.first else {
                debugPrint("Delete Done..")
                return
            }
            
            context.delete(del as! NSManagedObject)
            try context.save()
            
        }catch{
            debugPrint("Delete Error")
        }
        
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let update = UIContextualAction(style: .normal, title: "Update") { _, _, complete in
        
            self.getID = self.dataArr[indexPath.row]
            self.performSegue(withIdentifier: "updateDataSegue", sender: self)
            
            complete(true)
                
        }
        update.backgroundColor = .brown
        return UISwipeActionsConfiguration(actions: [update])
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "updateDataSegue" {
            if let updateVc = segue.destination as? UpdateDataVC{
                updateVc.readdata = self.getID
            }
        }
    }
 
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}
